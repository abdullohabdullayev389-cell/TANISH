# 💕 TanishBot — Telegram Tanishuvlar Boti

## Buyruqlar
| Buyruq | Vazifasi |
|--------|----------|
| `/start` | Ro'yxatdan o'tish |
| `/topish` | Yangi odamlarni ko'rish |
| `/moslashuvlar` | Matchlar ro'yxati |
| `/profil` | O'z profilingiz |
| `/reset` | O'tkazilganlarni tozalash |

## GitHub → Render Deploy

### 1. GitHub
```bash
git init
git add .
git commit -m "TanishBot"
git remote add origin https://github.com/SIZNING/tanishbot.git
git push -u origin main
```

### 2. Render
1. [render.com](https://render.com) → **New → Background Worker**
2. GitHub reponi ulang
3. **Environment Variables** → `BOT_TOKEN` = sizning tokeningiz
4. **Deploy**

### BotFather'dan token olish
1. Telegram'da [@BotFather](https://t.me/BotFather) ga yozing
2. `/newbot` → nom bering
3. Token nusxalab oling
