import logging
import random
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes, ConversationHandler
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TOKEN = os.environ.get("BOT_TOKEN")

# Conversation states
NAME, AGE, CITY, BIO, GENDER, LOOKING_FOR = range(6)

# In-memory database (Render uchun yetarli, keyinchalik PostgreSQL qo'shish mumkin)
users = {}       # {user_id: {...profile}}
likes = {}       # {user_id: [liked_user_ids]}
matches = {}     # {user_id: [matched_user_ids]}
passes = {}      # {user_id: [passed_user_ids]}


def get_profile_text(profile: dict) -> str:
    gender_emoji = "👩" if profile.get("gender") == "ayol" else "👨"
    return (
        f"{gender_emoji} *{profile['name']}*, {profile['age']} yosh\n"
        f"📍 {profile['city']}\n\n"
        f"💬 _{profile['bio']}_"
    )


def get_next_user(current_id: int) -> dict | None:
    """Tasodifiy foydalanuvchi tanlash (ko'rilmaganlardan)"""
    seen = set(likes.get(current_id, []) + passes.get(current_id, []) + [current_id])
    current_profile = users.get(current_id, {})
    looking_for = current_profile.get("looking_for", "hammasi")

    candidates = []
    for uid, profile in users.items():
        if uid in seen:
            continue
        if looking_for != "hammasi":
            if profile.get("gender") != looking_for:
                continue
        candidates.append((uid, profile))

    if not candidates:
        return None

    uid, profile = random.choice(candidates)
    profile["_id"] = uid
    return profile


async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in users:
        await update.message.reply_text(
            "👋 Xush kelibsiz! /topish — yangi odamlarni ko'rish\n"
            "/moslashuvlar — matchlaringiz\n"
            "/profil — profilingiz"
        )
        return ConversationHandler.END

    await update.message.reply_text(
        "💕 *TanishBot*'ga xush kelibsiz!\n\n"
        "Ro'yxatdan o'tish uchun bir necha savol beramiz.\n\n"
        "Ismingizni kiriting:",
        parse_mode="Markdown"
    )
    return NAME


async def get_name(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["name"] = update.message.text.strip()
    await update.message.reply_text("Yoshingiz nechida?")
    return AGE


async def get_age(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit() or not (16 <= int(text) <= 60):
        await update.message.reply_text("❌ Iltimos, to'g'ri yosh kiriting (16-60):")
        return AGE
    ctx.user_data["age"] = int(text)
    await update.message.reply_text("Qaysi shaharda yashaysiz?")
    return CITY


async def get_city(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["city"] = update.message.text.strip()
    await update.message.reply_text("O'zingiz haqingizda qisqacha yozing (bio):")
    return BIO


async def get_bio(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["bio"] = update.message.text.strip()
    keyboard = [[
        InlineKeyboardButton("👨 Erkak", callback_data="gender_erkak"),
        InlineKeyboardButton("👩 Ayol", callback_data="gender_ayol"),
    ]]
    await update.message.reply_text(
        "Jinsingiz?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return GENDER


async def get_gender(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    ctx.user_data["gender"] = query.data.split("_")[1]

    keyboard = [[
        InlineKeyboardButton("👨 Erkak", callback_data="looking_erkak"),
        InlineKeyboardButton("👩 Ayol", callback_data="looking_ayol"),
        InlineKeyboardButton("🌈 Hammasi", callback_data="looking_hammasi"),
    ]]
    await query.message.reply_text(
        "Kimni qidiryapsiz?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return LOOKING_FOR


async def get_looking_for(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    ctx.user_data["looking_for"] = query.data.split("_")[1]

    user_id = query.from_user.id
    users[user_id] = ctx.user_data.copy()
    likes[user_id] = []
    passes[user_id] = []
    matches[user_id] = []

    await query.message.reply_text(
        f"✅ Profil yaratildi!\n\n{get_profile_text(users[user_id])}\n\n"
        "/topish — odamlarni ko'rish boshlang!",
        parse_mode="Markdown"
    )
    return ConversationHandler.END


async def topish(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in users:
        await update.message.reply_text("Avval ro'yxatdan o'ting: /start")
        return

    candidate = get_next_user(user_id)
    if not candidate:
        await update.message.reply_text(
            "😔 Hozircha ko'rsatadigan odam qolmadi.\n"
            "Keyinroq qaytib keling yoki /reset bilan o'chirilganlarni qaytaring."
        )
        return

    cid = candidate["_id"]
    keyboard = [[
        InlineKeyboardButton("✖️ Pass", callback_data=f"pass_{cid}"),
        InlineKeyboardButton("❤️ Like", callback_data=f"like_{cid}"),
    ], [
        InlineKeyboardButton("⭐ Super Like", callback_data=f"superlike_{cid}"),
    ]]
    await update.message.reply_text(
        get_profile_text(candidate),
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def handle_action(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    action, target_id_str = query.data.rsplit("_", 1)
    target_id = int(target_id_str)

    if action == "pass":
        passes.setdefault(user_id, []).append(target_id)
        await query.edit_message_reply_markup(reply_markup=None)
        await show_next(query, user_id)

    elif action in ("like", "superlike"):
        likes.setdefault(user_id, []).append(target_id)
        emoji = "⭐" if action == "superlike" else "❤️"

        # Match tekshirish
        if user_id in likes.get(target_id, []):
            matches.setdefault(user_id, []).append(target_id)
            matches.setdefault(target_id, []).append(user_id)

            await query.edit_message_reply_markup(reply_markup=None)
            await query.message.reply_text(
                f"🎉 *Moslik topildi!*\n\n"
                f"{users[target_id]['name']} ham sizni yoqtirgan edi!\n"
                f"/moslashuvlar — barchani ko'rish",
                parse_mode="Markdown"
            )
            # Target foydalanuvchiga xabar
            try:
                await ctx.bot.send_message(
                    chat_id=target_id,
                    text=f"🎉 *Moslik!* {users[user_id]['name']} bilan moslashdingiz!\n/moslashuvlar",
                    parse_mode="Markdown"
                )
            except Exception:
                pass
        else:
            await query.edit_message_reply_markup(reply_markup=None)
            await query.message.reply_text(f"{emoji} Yoqtirdingiz!")

            if action == "superlike":
                try:
                    await ctx.bot.send_message(
                        chat_id=target_id,
                        text=f"⭐ Kimdir sizni *Super Like* qildi! /topish",
                        parse_mode="Markdown"
                    )
                except Exception:
                    pass

        await show_next(query, user_id)


async def show_next(query, user_id: int):
    candidate = get_next_user(user_id)
    if not candidate:
        await query.message.reply_text("😔 Ko'rsatadigan odam qolmadi. Keyinroq keling!")
        return

    cid = candidate["_id"]
    keyboard = [[
        InlineKeyboardButton("✖️ Pass", callback_data=f"pass_{cid}"),
        InlineKeyboardButton("❤️ Like", callback_data=f"like_{cid}"),
    ], [
        InlineKeyboardButton("⭐ Super Like", callback_data=f"superlike_{cid}"),
    ]]
    await query.message.reply_text(
        get_profile_text(candidate),
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def moslashuvlar(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_matches = matches.get(user_id, [])

    if not user_matches:
        await update.message.reply_text("💔 Hali moslashuvlar yo'q.\n/topish — odamlarni ko'ring!")
        return

    text = "💕 *Moslashuvlaringiz:*\n\n"
    for mid in user_matches:
        if mid in users:
            p = users[mid]
            text += f"• {p['name']}, {p['age']} — {p['city']}\n"

    await update.message.reply_text(text, parse_mode="Markdown")


async def profil(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in users:
        await update.message.reply_text("Avval /start bilan ro'yxatdan o'ting.")
        return

    profile = users[user_id]
    stats = (
        f"❤️ Like berilgan: {len(likes.get(user_id, []))}\n"
        f"💕 Moslashuvlar: {len(matches.get(user_id, []))}\n"
    )
    await update.message.reply_text(
        f"{get_profile_text(profile)}\n\n{stats}",
        parse_mode="Markdown"
    )


async def reset_passes(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    passes[user_id] = []
    await update.message.reply_text("✅ O'tkazib yuborilganlar tozalandi! /topish")


def main():
    app = Application.builder().token(TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_name)],
            AGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_age)],
            CITY: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_city)],
            BIO: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_bio)],
            GENDER: [CallbackQueryHandler(get_gender, pattern="^gender_")],
            LOOKING_FOR: [CallbackQueryHandler(get_looking_for, pattern="^looking_")],
        },
        fallbacks=[CommandHandler("start", start)],
    )

    app.add_handler(conv)
    app.add_handler(CommandHandler("topish", topish))
    app.add_handler(CommandHandler("moslashuvlar", moslashuvlar))
    app.add_handler(CommandHandler("profil", profil))
    app.add_handler(CommandHandler("reset", reset_passes))
    app.add_handler(CallbackQueryHandler(handle_action, pattern="^(like|pass|superlike)_"))

    logger.info("Bot ishga tushdi...")
    app.run_polling()


if __name__ == "__main__":
    main()
